
package main

import (
    "database/sql"
    "log"
    "time"
    _ "github.com/mattn/go-sqlite3"
)

var db *sql.DB

func main() {
    var err error
    db, err = sql.Open("sqlite3", "/var/lib/xin/guardian.db")
    if err != nil {
        log.Fatal(err)
    }
    initDB()

    for {
        status, reason := DiagnoseNode()
        if status != "GREEN" {
            RecordEvent("NODE_RED", reason, "AUTO_HEAL")
            Heal(reason)
        }
        time.Sleep(10 * time.Second)
    }
}
