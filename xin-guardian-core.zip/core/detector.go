
package main

import (
    "os/exec"
    "strings"
)

func DiagnoseNode() (string, string) {
    out, err := exec.Command("systemctl", "is-active", "docker").Output()
    if err != nil || strings.TrimSpace(string(out)) != "active" {
        return "RED", "Docker inactive"
    }

    out, err = exec.Command("systemctl", "is-active", "wings").Output()
    if err != nil || strings.TrimSpace(string(out)) != "active" {
        return "RED", "Wings inactive"
    }
    return "GREEN", "Healthy"
}
