
package main

import "os/exec"

func Heal(reason string) {
    switch reason {
    case "Docker inactive":
        exec.Command("systemctl", "restart", "docker").Run()
    case "Wings inactive":
        exec.Command("systemctl", "restart", "wings").Run()
    }
}
